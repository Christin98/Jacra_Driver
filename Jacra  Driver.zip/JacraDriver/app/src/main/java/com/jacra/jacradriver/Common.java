package com.jacra.jacradriver;

public class Common {
    public static final String DRIVER_LOCATION_REFERENCE = "DriverLocation";
}
